#!/bin/sh
./sorts "$@"

