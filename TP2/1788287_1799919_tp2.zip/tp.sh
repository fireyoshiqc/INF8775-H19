#!/bin/sh
./Restos "$@"

