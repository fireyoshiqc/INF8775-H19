#!/bin/sh
./Legos "$@"
